export * from "./single-column-page"
