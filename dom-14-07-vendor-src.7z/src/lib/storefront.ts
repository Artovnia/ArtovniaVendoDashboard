export const MEDUSA_STOREFRONT_URL =
  __STOREFRONT_URL__ ?? "http://localhost:8000"
