export { useRegisterShortcut } from "./hooks"
export * from "./keybind-provider"
export type { Shortcut, ShortcutType } from "./types"
