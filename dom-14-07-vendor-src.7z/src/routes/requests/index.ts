import { Requests } from "./requests-list/requests"

export default Requests
