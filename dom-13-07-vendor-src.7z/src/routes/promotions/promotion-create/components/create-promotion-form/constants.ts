export enum View {
  TEMPLATE = "template",
  PROMOTION = "promotion",
  CAMPAIGN = "campaign",
}

export enum Tab {
  TYPE = "type",
  PROMOTION = "promotion",
  CAMPAIGN = "campaign",
}
