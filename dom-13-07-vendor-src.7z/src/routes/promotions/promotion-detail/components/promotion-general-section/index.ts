export * from "./promotion-general-section.tsx"
