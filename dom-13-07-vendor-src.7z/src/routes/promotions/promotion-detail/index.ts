export { PromotionDetailBreadcrumb as Breadcrumb } from "./breadcrumb"
export { promotionLoader as loader } from "./loader.ts"
export { PromotionDetail as Component } from "./promotion-detail.tsx"
