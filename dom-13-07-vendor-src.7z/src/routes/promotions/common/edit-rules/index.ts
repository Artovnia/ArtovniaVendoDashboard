export { EditRules as Component } from "./edit-rules"
