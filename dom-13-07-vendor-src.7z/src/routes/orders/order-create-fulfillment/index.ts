export { OrderCreateFulfillment as Component } from "./order-create-fulfillments"
