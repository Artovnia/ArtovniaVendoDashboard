export { ClaimCreate as Component } from "./claim-create"
