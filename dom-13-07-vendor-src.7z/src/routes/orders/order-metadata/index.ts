export { OrderMetadata as Component } from "./order-metadata"
