export { OrderRequestTransfer as Component } from "./order-request-transfer"
