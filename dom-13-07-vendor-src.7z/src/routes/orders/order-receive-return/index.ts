export { OrderReceiveReturn as Component } from "./order-receive-return"
