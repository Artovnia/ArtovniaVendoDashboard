export { OrderCreateShipment as Component } from "./order-create-shipment"
