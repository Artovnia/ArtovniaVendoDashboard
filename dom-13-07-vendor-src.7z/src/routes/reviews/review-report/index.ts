export { ReviewReport as Component } from './review-report';
