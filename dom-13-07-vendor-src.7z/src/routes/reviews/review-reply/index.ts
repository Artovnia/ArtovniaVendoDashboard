export { ReviewReply as Component } from './review-reply';
