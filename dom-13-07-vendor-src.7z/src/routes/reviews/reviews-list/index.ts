export { ReviewList as Component } from './review-list';
