export { ReviewDetailBreadcrumb as Breadcrumb } from './breadcrumb';
export { reviewLoader as loader } from './loader';
export { ReviewDetail as Component } from './review-detail';
