export const REGION_DETAIL_FIELDS =
  "*payment_providers,*countries,+automatic_taxes"
