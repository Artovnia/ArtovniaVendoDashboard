export { RegionDetailBreadcrumb as Breadcrumb } from "./breadcrumb"
export { regionLoader as loader } from "./loader"
export { RegionDetail as Component } from "./region-detail"
