export { RegionEdit as Component } from "./region-edit"
