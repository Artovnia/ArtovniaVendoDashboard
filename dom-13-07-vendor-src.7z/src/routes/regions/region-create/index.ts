export { RegionCreate as Component } from "./region-create"
