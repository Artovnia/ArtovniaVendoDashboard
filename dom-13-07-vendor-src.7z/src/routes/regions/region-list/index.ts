export { RegionList as Component } from "./region-list"
