export { RegionMetadata as Component } from "./region-metadata.tsx"
