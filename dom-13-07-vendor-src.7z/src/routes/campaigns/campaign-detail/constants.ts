export const CAMPAIGN_DETAIL_FIELDS = "+promotions.id"
