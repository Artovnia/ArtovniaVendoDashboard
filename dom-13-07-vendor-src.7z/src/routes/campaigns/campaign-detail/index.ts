export { CampaignDetailBreadcrumb as Breadcrumb } from "./breadcrumb"
export { CampaignDetail as Component } from "./campaign-detail"
export { campaignLoader as loader } from "./loader"
