export { CampaignEdit as Component } from "./campaign-edit"
