export { CampaignList as Component } from "./campaign-list"
