export { CampaignCreate as Component } from "./campaign-create"
