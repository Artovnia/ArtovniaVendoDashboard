export { AddCampaignPromotions as Component } from "./add-campaign-promotions"
