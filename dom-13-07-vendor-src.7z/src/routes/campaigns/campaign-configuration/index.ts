export { CampaignConfiguration as Component } from "./campaign-configuration"
