export { CampaignBudgetEdit as Component } from "./campaign-budget-edit"
