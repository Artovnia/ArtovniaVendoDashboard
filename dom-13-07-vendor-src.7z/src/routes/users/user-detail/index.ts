export { UserDetailBreadcrumb as Breadcrumb } from "./breadcrumb"
export { userLoader as loader } from "./loader"
export { UserDetail as Component } from "./user-detail"
