export { UserMetadata as Component } from "./user-metadata"
