export { ProductPrices as Component } from "./product-prices"
