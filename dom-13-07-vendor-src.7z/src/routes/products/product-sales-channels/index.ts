export { ProductSalesChannels as Component } from "./product-sales-channels"
