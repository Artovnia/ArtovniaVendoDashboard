export { EditProductGPSR } from './edit-product-gpsr';
