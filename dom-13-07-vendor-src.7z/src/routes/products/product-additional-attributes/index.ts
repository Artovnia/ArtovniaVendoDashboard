export { ProductAdditionalAttributesForm as Component } from "./ProductAdditionalAttributesForm"
