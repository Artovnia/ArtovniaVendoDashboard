export { ProductMetadata as Component } from "./product-metadata"
