export { ProductShippingProfile as Component } from "./product-shipping-profile"
