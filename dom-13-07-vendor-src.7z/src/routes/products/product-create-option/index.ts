export { ProductCreateOption as Component } from "./product-create-option"
