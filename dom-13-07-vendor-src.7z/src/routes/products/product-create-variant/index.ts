export { ProductCreateVariant as Component } from "./product-create-variant"
