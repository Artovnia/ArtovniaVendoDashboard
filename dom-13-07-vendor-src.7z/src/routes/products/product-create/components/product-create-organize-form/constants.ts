export const SC_STACKED_MODAL_ID = "sc"
