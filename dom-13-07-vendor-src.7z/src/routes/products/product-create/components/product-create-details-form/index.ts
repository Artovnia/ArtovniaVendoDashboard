export * from "./product-create-details-form"
