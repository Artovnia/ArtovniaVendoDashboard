export { ProductCreateGPSRSection } from './product-create-gpsr-section';
