export { productStockLoader as loader } from "./loader"
export { ProductStock as Component } from "./product-stock"
