export { ProductAttributes as Component } from "./product-attributes"
