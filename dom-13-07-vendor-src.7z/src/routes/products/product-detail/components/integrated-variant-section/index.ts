// Export the main component
export { IntegratedVariantSection } from "./integrated-variant-section"
// Also export the variant row component for direct usage if needed
export { VariantRow } from "./variant-row"
