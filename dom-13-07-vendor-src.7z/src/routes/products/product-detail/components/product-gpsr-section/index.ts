export { ProductGPSRSection } from './product-gpsr-section';
