export { productTagListLoader as loader } from "./loader"
export { ProductTagList as Component } from "./product-tag-list"
