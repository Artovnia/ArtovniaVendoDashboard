export { ProductTagDetailBreadcrumb as Breadcrumb } from "./breadcrumb"
export { productTagLoader as loader } from "./loader"
export { ProductTagDetail as Component } from "./product-tag-detail"
