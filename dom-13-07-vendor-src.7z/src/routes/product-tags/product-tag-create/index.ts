export { ProductTagCreate as Component } from "./product-tag-create"
