export { ProductTagEdit as Component } from "./product-tag-edit"
